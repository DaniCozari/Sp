
package singleton.command;

public interface Command {
  public void execute();
}
